﻿using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using TodoList.Models;

namespace TodoList.Controllers
{
	public class TaskController : Controller
	{
	    [HttpGet]
        [Route("")]
	    public ActionResult Index()
	    {
            using (var db = new TodoListDbContext())
            {
                var tasks = db.Tasks.ToList();
                return View(tasks);
            }
        }

        [HttpGet]
        [Route("create")]
        public ActionResult Create()
		{
            return View();
        }

		[HttpPost]
		[Route("create")]
        [ValidateAntiForgeryToken]
		public ActionResult Create(Task task)
		{
		    if (task == null || !ModelState.IsValid)
            {
                return View(task);
            }

            using (var db = new TodoListDbContext())
            {
                db.Tasks.Add(task);
                db.SaveChanges();
            }

            return RedirectToAction("Index");
        }

		[HttpGet]
		[Route("delete/{id}")]
        public ActionResult Delete(int? id)
		{
            if (id == null)
            {
                return RedirectToAction("Index");
            }
            using (var db = new TodoListDbContext())
            {
                Task task = db.Tasks.Where(t => t.Id == id).First();
                if (task != null)
                {
                    return View(task);
                }
                return HttpNotFound();
            }

        }

        [HttpPost]
        [Route("delete/{id}")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirm(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            using (var db = new TodoListDbContext())
            {

                Task task = db.Tasks.Where(a => a.Id == id)
                    .First();

                if (task == null)
                {
                    return HttpNotFound();
                }

                db.Tasks.Remove(task);
                db.SaveChanges();

                return RedirectToAction("Index");
            }
        }
	}
}