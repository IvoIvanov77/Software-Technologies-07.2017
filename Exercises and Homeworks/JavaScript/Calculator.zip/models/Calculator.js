function Calculator(leftOperand, rightOperand, operator) {
    this.leftOperand = leftOperand;
    this.rightOperand = rightOperand;
    this.operator = operator;

    this.calculate = function () {
        switch (this.operator){
            case "+" : return this.leftOperand + this.rightOperand;
            case "-" : return this.leftOperand - this.rightOperand;
            case "*" : return this.leftOperand * this.rightOperand;
            case "/" : return this.leftOperand / this.rightOperand;
        }

    }
}

module.exports = Calculator;

