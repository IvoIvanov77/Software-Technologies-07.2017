const Calculator = require('./../models/Calculator');

module.exports = {
    indexGet: (req, res) => {
        res.render('home/index');
    },
    indexPost: (req, res) => {
        let calculatorData = req.body['calculator'];
        //console.log(calculatorData);

        let leftOperand = Number(calculatorData.leftOperand);
        //console.log(leftOperand);
        let rightOperand = Number(calculatorData.rightOperand);
        let operator = calculatorData.operator;

        let calculator = new Calculator(leftOperand, rightOperand, operator);

        let result = calculator.calculate();

        res.render('home/index', {'calculator': calculator, 'result' : result} );

    }

};