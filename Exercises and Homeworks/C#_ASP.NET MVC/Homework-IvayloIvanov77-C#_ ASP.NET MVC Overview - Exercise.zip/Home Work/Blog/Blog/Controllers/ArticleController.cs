﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Blog.Models;

namespace Blog.Controllers
{
    public class ArticleController : Controller
    {
        // GET: Article
        public ActionResult Index()
        {
            return RedirectToAction("List");
        }

        public ActionResult List()
        {
            using (var database = new BlogDbContext())
            {
                var articles = database.Articles
                    .Include(a => a.Author)
                    .ToList();
                return View(articles);
            }
           
        }

        public ActionResult Details(int? id)
        {
            if(id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            using (var db = new BlogDbContext())
            {
                Article article = db.Articles.Where(a => a.Id == id)
                    .Include(a => a.Author)
                    .First();
                if(article != null)
                {
                    return View(article);
                }
                return HttpNotFound();
              
            }
           
        }

        [HttpGet]
        [Authorize]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [Authorize]
        public ActionResult Create(Article article)
        {
           
            if (ModelState.IsValid)
            {                
                using (var db = new BlogDbContext())
                {
                    var author = User.Identity.Name;
                    var authorId = db.Users.Where(u => u.UserName == author)
                        .First().Id;
                    article.AuthorId = authorId;
                    db.Articles.Add(article);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            
            return View(article);
        }

        [HttpGet]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            using (var db = new BlogDbContext())
            {
                Article article = db.Articles.Where(a => a.Id == id).First();

                if (!IsUserAuthorizedToEdit(article))
                {
                    return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
                }

                if (article != null)
                {
                    return View(article);
                }
                return HttpNotFound();

            }
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteAction(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            using (var db = new BlogDbContext())
            {

                Article article = db.Articles.Where(a => a.Id == id)
                    .Include(a => a.Author)
                    .First();
               
                if (article == null)
                {
                    return HttpNotFound();
                }

                db.Articles.Remove(article);
                db.SaveChanges();

                return RedirectToAction("Index");

            }
        }

        [HttpGet]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            using (var db = new BlogDbContext())
            {
                Article article = db.Articles.Where(a => a.Id == id).First();

                if (!IsUserAuthorizedToEdit(article))
                {
                    return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
                }

                if (article == null)
                {
                    return HttpNotFound();
                }
                ArticleViewModel model = new ArticleViewModel()
                {
                    Id = article.Id,
                    Title = article.Title,
                    Content = article.Content
                };
                return View(model);

            }
        }

        [HttpPost]        
        public ActionResult Edit(ArticleViewModel model)
        {
            if (ModelState.IsValid)
            {
                using(var db = new BlogDbContext())
                {
                    Article article = db.Articles
                        .FirstOrDefault(a => a.Id == model.Id);
                    article.Title = model.Title;
                    article.Content = model.Content;

                    db.Entry(article).State = EntityState.Modified;
                    db.SaveChanges();

                    return RedirectToAction($"Details/{model.Id}");
                }
            }
            return View(model);
        }

        private bool IsUserAuthorizedToEdit(Article article)
        {
            return article.IsAuthor(User.Identity.Name)
                || User.IsInRole("Admin");
        }
    }
}