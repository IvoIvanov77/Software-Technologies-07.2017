﻿using System;
using System.Web.Mvc;
using Calculator_CSharp.Models;

namespace Calculator_CSharp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(Calculator calculator)
        {
            return View(calculator);
        }

        [HttpPost]
        public ActionResult Calculate(Calculator calcolator)
        {
            calcolator.Result = CalculateResult(calcolator);

            return RedirectToAction("Index", calcolator);
        }

        private decimal CalculateResult(Calculator calcolator)
        {
            switch (calcolator.Operator)
            {
                case "+": return calcolator.LeftOperand + calcolator.RightOperand;
                case "-": return calcolator.LeftOperand - calcolator.RightOperand;
                case "*": return calcolator.LeftOperand * calcolator.RightOperand;
                case "/": return calcolator.LeftOperand / calcolator.RightOperand;
                default:
                    return 0;
            }
        }
    }
}