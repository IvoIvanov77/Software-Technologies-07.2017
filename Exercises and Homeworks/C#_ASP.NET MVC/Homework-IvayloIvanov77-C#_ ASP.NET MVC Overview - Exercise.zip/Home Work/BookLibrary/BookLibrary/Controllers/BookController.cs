﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BookLibrary.Models;
using Microsoft.AspNet.Identity;
using System.Data.Entity;
using System.Net;

namespace BookLibrary.Controllers
{
    public class BookController : Controller
    {
        // GET: Book
        public ActionResult Index()
        {
            using(var db = new ApplicationDbContext())
            {
                var books = db.Books.Include(b => b.Author).ToList();
                return View(books);
            }
            
        }

        // GET: Book/Details/5
        public ActionResult Details(int? id)
        {
            if(id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            using (var db = new ApplicationDbContext())
            {
                var book = db.Books.Include(b => b.Author).FirstOrDefault(b => b.Id == id);
                if(book == null)
                {
                    return HttpNotFound();
                }
                return View(book);
            }
            
        }

        // GET: Book/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Book/Create
        [HttpPost]
        public ActionResult Create(Book book)
        {
            if (ModelState.IsValid)
            {
                using (var db = new ApplicationDbContext())
                {

                    book.AuthorId = User.Identity.GetUserId();
                    db.Books.Add(book);
                    db.SaveChanges();
                    return RedirectToAction("index");
                }
            }
            return View(book);
        }

        // GET: Book/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            using (var db = new ApplicationDbContext())
            {
                var book = db.Books.FirstOrDefault(b => b.Id == id);
                if (book == null)
                {
                    return HttpNotFound();
                }
                return View(book);
            }
        }

        // POST: Book/Edit/5
        [HttpPost]
        public ActionResult Edit(Book model)
        {
            if (ModelState.IsValid)
            {
                using (var db = new ApplicationDbContext())
                {
                    Book book = db.Books
                        .FirstOrDefault(a => a.Id == model.Id);
                    book.Title = model.Title;
                    book.Description = model.Description;

                    db.Entry(book).State = EntityState.Modified;
                    db.SaveChanges();

                    return RedirectToAction($"Details/{model.Id}");
                }
            }
            return View(model);
        }

        // GET: Book/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            using (var db = new ApplicationDbContext())
            {
                var book = db.Books.Include(b => b.Author).FirstOrDefault(b => b.Id == id);
                if (book == null)
                {
                    return HttpNotFound();
                }
                return View(book);
            }
        }

        // POST: Book/Delete/5
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteAction(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            using (var db = new ApplicationDbContext())
            {
                var book = db.Books.FirstOrDefault(b => b.Id == id);
                if (book == null)
                {
                    return HttpNotFound();
                }
                db.Books.Remove(book);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
        }
    }
}
